<!DOCTYPE html>



<html>
    <head>
        <title>Azam</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
        
		
		<link rel="stylesheet" href="css1/nicepage.css" media="screen">
<link rel="stylesheet" href="css1/Home.css" media="screen">
    <script class="u-script" type="text/javascript" src="js1/jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="js1/nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 3.22.0, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">


        <!-- Pace.js -->
        <script src="js1/pace.js" type="text/javascript"> </script>
        
        <!-- Foundations 5 Stylesheet-->
        <link href="css1/foundation.css" type="text/css" rel="stylesheet" media="screen" />
        
        <!-- Normalize-->
        <link href="css1/normalize.css" type="text/css" rel="stylesheet" media="screen" />
        
        <!-- Source Sans Pro Google Web Font-->
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700,400italic,600italic,700italic&subset=latin,vietnamese,latin-ext' rel='stylesheet' type='text/css'>
        
        <!-- Font Awesome Web Font Icons-->
        <link href="css1/font-awesome.min.css" type="text/css" rel="stylesheet" media="screen" />
        
        <!-- General Stylesheet-->
        <link href="css1/style.css" type="text/css" rel="stylesheet" media="screen" />
        
        <!-- jQuery Library 1.11.0 -->
        <script type="text/javascript" src="js1/jquery-1.11.0.min.js"> </script>
        
        <!-- Modernizr v2.7.1 -->
        <script src="js1/modernizr.js" type="text/javascript"> </script>
        
        <!-- Foundations 5 -->
        <script src="js1/foundation.min.js" type="text/javascript"> </script>

        <!-- Caroufredsel jQuery Plugin -->
        <script src="js1/jquery.carouFredSel-6.2.1-packed.js" type="text/javascript"> </script>
        
        <!-- Isotope jQuery Plugin -->
        <script src="js1/jquery.isotope.js" type="text/javascript"> </script>
        
        <!-- Appear Plugin -->
        <script src="js1/appear.js" type="text/javascript"> </script>
        
        <!-- General Initialization -->
        <script src="js1/general.js" type="text/javascript"> </script>
        
    </head>
    
    <body style="background:linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), url(assets/style_login/image/bgimg.jpg); background-repeat: no-repeat;
    background-attachment: fixed;height: 100vh;
	-webkit-background-size: cover;
	background-size: cover;
	background-position: center center;
	position: relative;
    background: 0.5;" id="home">
       
       <!-- Back to Top Button --> 
       <a href="#home" class="scroll backtotop">
           <i class="fa fa-angle-up"> </i>
       </a>
        
       <!-- Start of Header --> 
       <header> 
           <div class="row"> 
               <div class="large-9 medium-16 column"> 
                   <div class="logoholder">
                       <a href="#home" class="scroll"><img src="assets/style_login/image/logo.png" style="max-width: 22%;max-height:22%;" alt="" title=""></a><span style="color:#d40505;font-size: 60px;padding-top: 40px;margin-left: 60px;"><b>AZAM</b></span> <h3 style="font-size: 25px;margin-left: 250px;margin-top:-7%;line-height: 2px;"><b> Facilities Management</b></h3>
                   </div>
               </div>
               <div class="large-3 medium-16 column">
                   <nav> 
                       <ul> 
                           <li><a href="#home" class="scroll">Home</a></li>
                           <li>/</li>
                           <li><a href="#about" class="scroll">About</a></li>
                           <li>/</li>
                           <li><a href="{{route('login')}}" >Login</a></li>
                           
                       </ul>
                   </nav>
               </div>
               
               <div class="large-12 column">
                 
               </div>
               
           </div>
       </header>
       <!-- End of Header -->
       
       <!-- Start of About --> <br><br><br>
       <section class="about" id="about">
        <marquee style="background-color: #f3ca2f;font-size: 20px;height: 20px;"><b> Contact Us: <span style="margin-left: 20px"> 04 269 5096  </span>       <span style="margin-left: 20px">  050 770 6055 </span>  <span style="margin-left: 20px"> info@azamfacilities.com</span></b></marquee>
   
        <div class="row"> 
               
               <div class="large-8 large-centered column">
                   <div class="title">
                       
                       <p></p>
                   </div>
               </div>
               
               <div class="large-4 hide-for-medium-only hide-for-small-only column start"> 
                   <div class="imageholder">
                    
                   </div>
               </div>
            
               



                <div class="large-16 medium-16 large-uncentered medium-centered small-centered column">
                   <div class="sliderHolder">
                    <div id="cincopa_ee1b41">...</div><script type="text/javascript">
						var cpo = []; cpo["_object"] ="cincopa_ee1b41"; cpo["_fid"] = "A0AAp3OeWhF_";
						var _cpmp = _cpmp || []; _cpmp.push(cpo);
						(function() { var cp = document.createElement("script"); cp.type = "text/javascript";
						cp.async = true; cp.src = "https://rtcdn.cincopa.com/libasync.js";
						var c = document.getElementsByTagName("script")[0];
						c.parentNode.insertBefore(cp, c); })(); </script>
                       </div>
               </div>

              

<br><br><br><br><br><br><br><br><br><br><br><br><br>
<section class="u-align-center u-clearfix u-section-1"  id="sec-d275" style="background-image: none">
	<div class="u-clearfix u-sheet u-sheet-1">
	  <div class="u-expanded-width u-list u-list-1">
		<div class="u-repeater u-repeater-1">
		  <div class="u-container-style u-list-item u-repeater-item u-shape-rectangle u-list-item-1" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
			<div class="u-container-layout u-similar-container u-container-layout-1"><span class="u-file-icon u-icon u-icon-circle u-text-palette-1-base u-icon-1" data-animation-name="slideIn" data-animation-duration="1000" data-animation-delay="0" data-animation-direction="Down"><img src="assets/style_login/image/Cleaning.jpg" alt=""></span>
			  <h4 class="u-align-center u-custom-font u-text u-text-custom-color-3 u-text-1">Building Cleaning </h4>
			</div>
		  </div>
		  <div class="u-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-list-item-2" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
			<div class="u-container-layout u-similar-container u-container-layout-2"><span class="u-file-icon u-icon u-icon-circle u-text-palette-1-base u-icon-2" data-animation-name="slideIn" data-animation-duration="1000" data-animation-delay="0" data-animation-direction="Down"><img src="assets/style_login/image/img30.png" alt=""></span>
			  <h4 class="u-align-center u-custom-font u-text u-text-custom-color-3 u-text-2">Car Washing</h4>
			</div>
		  </div>
		  <div class="u-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-list-item-3" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
			<div class="u-container-layout u-similar-container u-container-layout-3"><span class="u-file-icon u-icon u-icon-circle u-text-palette-1-base u-icon-3" data-animation-name="slideIn" data-animation-duration="1000" data-animation-delay="0" data-animation-direction="Down"><img src="assets/style_login/image/img25.png" alt=""></span>
			  <h4 class="u-align-center u-custom-font u-text u-text-custom-color-3 u-text-3">Casual Staff</h4>
			</div>
		  </div>
		  <div class="u-container-style u-list-item u-repeater-item u-shape-rectangle u-list-item-4" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
			<div class="u-container-layout u-similar-container u-container-layout-4"><span class="u-file-icon u-icon u-icon-circle u-text-palette-1-base u-icon-4" data-animation-name="slideIn" data-animation-duration="1000" data-animation-delay="0" data-animation-direction="Down"><img src="assets/style_login/image/img10.png" alt=""></span>
			  <h4 class="u-align-center u-custom-font u-text u-text-custom-color-3 u-text-4">Landscaping</h4>
			</div>
		  </div>
		</div>
	  </div>
	  <div class="u-expanded-width u-list u-list-2">
		<div class="u-repeater u-repeater-2">
		  <div class="u-container-style u-list-item u-repeater-item u-shape-rectangle" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
			<div class="u-container-layout u-similar-container u-container-layout-5"><span class="u-file-icon u-icon u-icon-circle u-text-palette-1-base u-icon-5" data-animation-name="rotateIn" data-animation-duration="1000" data-animation-delay="0" data-animation-direction=""><img src="assets/style_login/image/Airconditioner.jpg" alt=""></span>
			  <h4 class="u-align-center u-custom-font u-text u-text-custom-color-3 u-text-5">Airconditioning&nbsp;</h4>
			</div>
		  </div>
		  <div class="u-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
			<div class="u-container-layout u-similar-container u-container-layout-6"><span class="u-file-icon u-icon u-icon-circle u-text-palette-1-base u-icon-6" data-animation-name="rotateIn" data-animation-duration="1000" data-animation-delay="0" data-animation-direction=""><img src="assets/style_login/image/Electritions.png" alt=""></span>
			  <h4 class="u-align-center u-custom-font u-text u-text-custom-color-3 u-text-6">Electriction</h4>
			</div>
		  </div>
		  <div class="u-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
			<div class="u-container-layout u-similar-container u-container-layout-7"><span class="u-file-icon u-icon u-icon-circle u-text-palette-1-base u-icon-7" data-animation-name="rotateIn" data-animation-duration="1000" data-animation-delay="0" data-animation-direction=""><img src="assets/style_login/image/Painters.jpg" alt=""></span>
			  <h4 class="u-align-center u-custom-font u-text u-text-custom-color-3 u-text-7">Painting</h4>
			</div>
		  </div>
		  <div class="u-container-style u-list-item u-repeater-item u-shape-rectangle" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
			<div class="u-container-layout u-similar-container u-container-layout-8"><span class="u-file-icon u-icon u-icon-circle u-text-palette-1-base u-icon-8" data-animation-name="rotateIn" data-animation-duration="1000" data-animation-delay="0" data-animation-direction=""><img src="assets/style_login/image/Domestic Cleaner.jpg" alt=""></span>
			  <h4 class="u-align-center u-custom-font u-text u-text-custom-color-3 u-text-8">Domestic Cleaner</h4>
			</div>
		  </div>
		</div>
	  </div>
	  <a href="https://wa.me/971507706055" class="u-border-none u-btn u-btn-round u-button-style u-custom-color-2 u-custom-font u-hover-palette-2-light-1 u-radius-50 u-btn-1">
		<span style="font-size: 3rem;">Book NOw <img style="width: 7%; haight:20%;" src="assets/style_login/image/whatsicon.png"> </img>    </span>
		<br>
	  </a>
	</div>
  </section>

  



                      </section>
       <!-- End of Contact -->
       
       <!-- Start of Footer -->
       <!-- <footer>
           <div class="row">
               <div class="large-6 medium-12 column">
                   <ul class="social fa-ul"> 
                        <li><a href="#"><i class="fa fa-li fa-dribbble"> </i> <span>DRIBBLE<span></a></li>
                        <li><a href="#"><i class="fa fa-li fa-twitter"> </i> <span>TWITTER<span></a></li>
                        <li><a href="#"><i class="fa fa-li fa-skype"> </i> <span>SKYPE<span></a></li>                
                   </ul>
               </div>
               <div class="large-6 medium-12 column">
                   <div class="copyright">
                       © Azam Facilities Management , ALL RIGHTS RESERVED Create By <a href="http://azamfacilities.com">Azam GOC</a>
                   </div>   
               </div>
           </div>
       </footer>
       End of Footer -->
       
    </body>
</html>
